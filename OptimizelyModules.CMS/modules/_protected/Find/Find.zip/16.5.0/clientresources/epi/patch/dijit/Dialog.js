//>>built
define("epi/patch/dijit/Dialog",["dojo/_base/lang","dijit/Dialog"],function(_1,_2){_1.mixin(_2.prototype,{_onBlur:function(){}});_2.prototype._onBlur.nom="_onBlur";});