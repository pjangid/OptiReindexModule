﻿define("epi-find/manage/DashboardController", [
    "dojo/_base/declare",
    "dojo/_base/config",

    "../_ControllerBase",
    "../widget/SwoshContainer",
    "../widget/_SwoshPaneBase",
    "../widget/_ActionableMixin",

    "../widget/Dashboard",
    "./DashboardModel"
],
function(declare, config,
    _ControllerBase, SwoshContainer, _SwoshPaneBase, _ActionableMixin,
    DashboardWidget, DashboardModel
) {
    return declare([_ControllerBase, _ActionableMixin], {
        // summary:
        //      Controller for Dashboard views.

        model: null,
        swoshContainer: null,
        dashboard: null,

        startup: function() {
            if (this.isStarted()) {
                return;
            }
            this.inherited(arguments);
            this.model = new DashboardModel();
            this.model.init();

            var DashboardPane = declare([_SwoshPaneBase, DashboardWidget]);
            this.dashboard = new DashboardPane({
                    model: this.model,
                    name: "dashboard",
                    location: "left"
                });

            this.registerAction(this.dashboard.name, this.dashboard);

            this.swoshContainer = new SwoshContainer({
                model: this.model,
                swoshPanes: [{
                    intent: config.intents.view.dashboard,
                    widget: this.dashboard
                }]
            });
            this.own(this.swoshContainer);

            this.currentAction = this.dashboard.name;
            this.previousActionFallback = true;
        },

        takeAction: function(actions, params) {
            if (!actions || !actions.length) {
                return this.inherited(arguments);
            }
            var activePane = this.findActionable(actions[0]);

            for(var i in this.swoshContainer.swoshPanes) {
                var widget = this.swoshContainer.swoshPanes[i].widget;
                if (activePane == widget) {
                    this.swoshContainer.setActiveWidget(i);
                }
            }
            this.inherited(arguments);
            return activePane;
        },

        refresh: function() {
            this.dashboard.refresh();
        },

        show: function() {
            this._setupView([this.swoshContainer]);
        }
    });
});