﻿define("epi-find/optimize/OptimizationModel", [
    "dojo/_base/declare",
    "dojo/_base/config",
    "dojo/Stateful",

    "dojo/store/Observable",
    "./RelatedQueriesModel",
    "./AutocompleteModel",

    "dijit/Destroyable"
],
function (
    declare,
    config,
    Stateful,
    Observable,
    RelatedQueriesModel,
    AutocompleteModel,
    Destroyable
    ) {

    return declare([Stateful, Destroyable], {
        // summary:
        //      Optimization model.

        relatedQueriesStore: null,
        autocompleteStore: null,

        relatedQueriesModel: null,
        autocompleteModel: null,

        constructor: function () {
            this.relatedQueriesStore = config.dependencies["epi-find.RelatedQueries"];
            this.autocompleteStore = config.dependencies["epi-find.Autocomplete"];
        },

        init: function () {
            this.relatedQueriesModel = new RelatedQueriesModel({
                store: this.relatedQueriesStore
            });

            this.autocompleteModel = new AutocompleteModel({
                store: new Observable(this.autocompleteStore)
            });
        }
    });
});
