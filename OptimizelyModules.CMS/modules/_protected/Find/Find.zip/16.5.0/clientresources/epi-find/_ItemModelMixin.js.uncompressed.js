﻿define("epi-find/_ItemModelMixin", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Stateful",
    "dojo/when",
    "dojo/Evented",
    "dojox/mvc/getStateful"

],

function (declare, lang, Stateful, when, Evented, getStateful) {

    return declare([Stateful, Evented], {
        // summary:
        //          Model mixin for navigating items in profile/segments views.

        // itemStore: store
        //      Instance created by implementing class
        itemStore: null,

        currentItem: null,
        _currentItemGetter: function () {
            return this.currentItem;
        },
        _currentItemSetter: function (value) {
            this.currentItem = this.onCurrentItemChange(value);
        },

        onCurrentItemChange: function(value) {
            // summary:
            //      This method can be overridden by the mixin users
            return getStateful(value);
        },

        currentItemId: null,

        nextItem: null,
        _nextItemGetter: function () {
            return this.nextItem;
        },
        _nextItemSetter: function (value) {
            this.nextItem = value;
        },
        previousItem: null,
        _previousItemGetter: function () {
            return this.previousItem;
        },
        _previousItemSetter: function (value) {
            this.previousItem = value;
        },

        currentItemIndex: -1,

        getDefaultItem: function() {
            // summary:
            //      This method can be overridden by mixin users
            return {}; // by default return an empty object
        },


        setCurrentItem: function (itemId) {

            if (this.currentItemId === itemId) {
                return;
            }
            this.currentItemId = itemId;

            if (this.nextItem && this.nextItem[this.itemStore.idProperty] === itemId) {
                this.selectNextItem();
            } else if (this.previousItem && this.previousItem[this.itemStore.idProperty] === itemId) {
                this.selectPreviousItem();
            } else {
                // Direct item request (probably from an external link)
                this.itemStore.get(this.currentItemId).then(lang.hitch(this, function (item) {
                    this.set("nextItem", null);
                    this.set("previousItem", null);
                    this.currentItemIndex = -1;
                    this.set("currentItem", item);
                }),
                lang.hitch(this, function (err) {
                    // TODO: Redirect to 404 view
                    console.warn("Item with id " + itemId + " not found");
                    this.set("nextItem", null);
                    this.set("previousItem", null);
                    this.currentItemIndex = -1;
                    this.set("currentItem", null);
                }));
            }
        },

        resetCurrentItem: function() {
            this.set("nextItem", null);
            this.set("previousItem", null);
            this.currentItemId = -1;
            this.set("currentItem", null);
        },

        setCurrentItemWithNavigation: function (rowIndex, itemId, animationDeferred){
            this.currentItemIndex = rowIndex;

            return this._updateCurrentItem(itemId, animationDeferred);
        },

        _updateCurrentItem: function (itemId, animationDeferred) {
            var startIndex = Math.max(0, this.currentItemIndex - 1);
            var count = Math.min(this.currentItemIndex === 0 ? 2 : 3, this.itemCount > 0 ? this.itemCount : 1);
            var options = { start: startIndex, count: count, sort: this.currentSort };

            var queryResults = this.itemStore.query(this.currentQuery, options);
            var query = queryResults.then(lang.hitch(this, function (results) {
                var currentItem;
                if (results.length === 3) { // we are in the middle of the list, so we have both previous and next nodes
                    this.set("previousItem", results[0]);
                    currentItem = results[1];
                    this.set("nextItem", results[2]);
                } else if (results.length === 2){ // we are in the top or bottom of the list
                    if (this.currentItemIndex === 0) { // we are in the top
                        this.set("previousItem", null);
                        currentItem = results[0];
                        this.set("nextItem", results[1]);
                    } else {                              //  we are in the bottom
                        this.set("previousItem", results[0]);
                        currentItem = results[1];
                        this.set("nextItem", null);
                    }
                } else if (results.length === 1) { // there is only one item
                    this.set("previousItem", null);
                    currentItem = results[0];
                    this.set("nextItem", null);

                }

                this.currentItemId = currentItem ? currentItem[this.itemStore.idProperty] : null;
                if (itemId && (!currentItem || this.currentItemId !== itemId)) { // if ID of an item from query does not equal to an ID of a clicked item - get item by ID and disable prev/next
                    this.itemStore.get(itemId).then(lang.hitch(this, function(item) {
                        currentItem = item;
                        this.set("previousItem", null);
                        this.set("nextItem", null);
                        when(animationDeferred, lang.hitch(this, function () {
                            this.currentItemId = currentItem[this.itemStore.idProperty];
                            this.set("currentItem", currentItem);
                        }));
                    }));
                }
                else if (currentItem) {
                    when(animationDeferred, lang.hitch(this, function () {
                        this.set("currentItem", currentItem);
                    }));
                }
            }));
            return query;
        },

        selectNextItem: function () {
            if (this.currentItemIndex < this.itemCount) {
                this.currentItemIndex += 1;
                this.emit("nextItem", this.currentItemIndex);
                this._updateCurrentItem(this.nextItem[this.itemStore.idProperty], null);
            }
        },

        selectPreviousItem: function () {
            if (this.currentItemIndex > 0) {
                this.currentItemIndex -= 1;
                this.emit("previousItem", this.currentItemIndex);
                this._updateCurrentItem(this.previousItem[this.itemStore.idProperty], null);
            }
        }

    });
});
